typedef struct fila * Fila;

#define tam 11

Fila cria_fila();
void liberar(Fila *f);
int fila_vazia(Fila f);
int fila_cheia(Fila f);
int inseri_fim(Fila f, char elem[]);
int remove_ini(Fila f, char elem[]);
