typedef struct fila * Fila;

#define tam 50

Fila cria_fila();
void liberar(Fila *f);
int fila_vazia(Fila f);
int fila_cheia(Fila f);
int inseri_fim(Fila f, int mat, char elem[], int falt, float med);
int remove_ini(Fila f, int *mat, char elem[], int *falt, float *med);
